<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="en" lang="en">
<head>
<title>15</title>
<meta http-equiv="Content-Type" content="text/html; charset=ISO-8859-1" />
<link rel="stylesheet" href="styles.css" type="text/css" />
</head>
<body>
<h1>Vertical CSS Navigation Menu</h1>
<hr />
<div id="menu">
  <ul>
    <li><a href="http://www.free-css.com/">CSS Templates</a></li>
    <li><a href="http://www.free-css.com/">CSS Layouts</a></li>
    <li><a href="http://www.free-css.com/">CSS Books</a></li>
    <li><a href="http://www.free-css.com/">CSS Menus</a></li>
    <li><a href="http://www.free-css.com/">CSS Tutorials</a></li>
    <li><a href="http://www.free-css.com/">CSS Reference</a></li>
    <li><a rel="nofollow" target="_blank" href="http://www.e-lusion.com/" title="E-lusion">E-lusion</a></li>
  </ul>
</div>
</body>
</html>
