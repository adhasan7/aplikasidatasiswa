<?php
//$host="localhost";
//$user="root";
//$pass="";
//$db="data_siswa_db";
//$koneksi=mysqli_connect($host,$user,$pass);
//if ($koneksi) 
//{
//mysqli_select_db($db,$koneksi) or die ("Error : ".mysqli_error());}

$server    = "localhost";
$username    = "root";
$password    = "";
$database   = "data_siswa_db";
$db = mysqli_connect($server, $username, $password, $database);
date_default_timezone_set('Asia/Jakarta');


?>
