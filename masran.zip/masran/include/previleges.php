<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
<title>Untitled Document</title>
</head>

<body>
<table background="../css/images/bg.jpg" width="400" border="0" align="center" style="margin-top:50px;">
  <tr>
    <th height="131" scope="col"><img src="../css/images/LO.png" width="290" height="220" /></th>
  </tr>
  <tr>
    <td height="245"><table bgcolor="#FFF" width="316" border="0" align="center" cellpadding="5px">
      <tr>
        <td colspan="3" align="center">&nbsp;</td>
      </tr>
      <tr>
        <td height="80" colspan="3" align="center"><p>Maaf anda tidak diizinkan <br />masuk ke halaman ini</p></td>
      </tr>
      
      <tr>
        <td width="29">&nbsp;</td>
        <td width="175">&nbsp;</td>
        <td width="74"><input type="submit" name="login" value="Halaman Login" onclick="window.location='../index.php'" /></td>
      </tr>
    </table></td>
  </tr>
  <tr>
    <td height="20" align="center"><font color="#FFFFFF"></font></td>
  </tr>
</table>
</body>
</html>