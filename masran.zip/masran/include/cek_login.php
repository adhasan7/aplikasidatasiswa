<?php
session_start();
include "../include/koneksi.php";

$id_user = $_POST['admin_username'];
$pass = $_POST['pass'];
$hash = md5($pass);
$op = $_GET['op'];
 

if($op=="in"){
	if(isset($_POST['login']))
	{
		//cek apakah semua kolom sudah terisi
		if(!$_POST['admin_username'] | !$_POST['pass'])
		{
			header("location:../index.php?err=1");
		}
		else
		{
    $cek = mysqli_query($db,"SELECT * FROM tbl_admin" WHERE admin_username='$id_user' AND admin_password='$hash'");
	$cek2 = mysqli_query($db,"SELECT * FROM tb_admin" WHERE admin_username='$id_user2' AND admin_password='$hash2'");
	
	
	
    if(mysql_num_rows($cek)==1){
        $c = mysql_fetch_array($cek);
        $_SESSION['admin_username'] = $c['admin_username'];
        $_SESSION['level'] = $c['admin_level'];
        if($c['admin_level']=="admin"){
            header("location:../Admin/index.php");           
        }
        else if($c['admin_level']=="petugas"){
            header("location:../Petugas/index.php");
        }
    }else
			{   
				//jika tidak, kembali ke index.php dengan pesan error
				header("location:../index.php?err=2");}
		}
	}
}else if($op=="out"){
    unset($_SESSION['admin_username']);
    unset($_SESSION['admin_level']);
    header("location:../index.php");
}
?>