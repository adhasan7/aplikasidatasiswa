<!-- awal -->
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
<title>SMK KUNCUP SAMIGALUH</title>
<link rel="stylesheet" href="../css/border.css" media="screen">
<link rel="stylesheet" type="text/css" href="../css/drop/pro_drop_1.css" />
<link rel="shotcut icon" href="../css/images/logoc.png" />


</head>

<body style="margin:0px;" background="../image/image1.jpg">

<div id="header">
	<img src="../css/images/header.jpg" width="955" height="153" style="float:left; margin-left:20px"/>
</div>

<div id="box" style="margin-top:0px;">
	<ul id="nav">
   	<li class="top"><a href="index.php" class="top_link"><span>Home</span></a></li>
    
    <li class="top"><a href="#" id="products" class="top_link"><span class="down">Data Master</span></a>
    	<ul class="sub">
			<li><a href="viewsiswa.php" >Siswa</a></li>
			<li><a href="kelas.php">Kelas</a></li>
			<li><a href="asal_sekolah.php">Asal Sekolah</a></li>
			<li><a href="pekerjaan.php">Pekerjaan</a></li>
			<li><a href="agama.php">Agama</a></li>
			<li><a href="tahun_ajar.php" >Tahun Ajar</a></li>
    </li>
		</ul>
        
    </li>
	
    <li class="top"><a href="#" id="products" class="top_link"><span class="down">Statistik</span></a>
    	<ul class="sub">
			<li><a href="stat_pekerjaan.php" >Pekerjaan</a></li>
			<li><a href="stat_gender.php" >Jenis Kelamin</a></li>  
     	</ul>   
    </li>
	 
    <li class="top"><a href="#" id="products" class="top_link"><span class="down">Kelas</span></a>
        <ul class="sub">
		 <?php
	 include "../include/koneksi.php";
	 
        $sql = mysql_query("SELECT * from tbl_kelas");
        while($r=mysql_fetch_array($sql)) {
		$id_kelas=$r['kd_kelas'];
 
            echo "<li><a href='list_perkelas.php?id_kelas=$id_kelas'>".$r['kelas']."</a>";
 
             echo "</li>";
            }
    ?>
		
		
         </ul>
	</li>
	<li class="top"><a href="#" id="products" class="top_link"><span class="down">Kenaikan</span></a>
        <ul class="sub">
		<li><a href="kenaikan_kelas.php" >Data kenaikan</a></li>
			<li><a href="carisiswa1.php" >Tambah Kenaikan</a></li>  
     	</ul>
	</li>
	
	
	<li class="top"><a href="rekap.php" id="products" class="top_link"><span>Rekap</span></a></li>
	
	<li class="top"><a href="user.php" id="products" class="top_link"><span>user</span></a></li>
	 
	<li class="top"><a href="#" class="top_link"><span>About</span></a></li>		
    
	<li class="top" onClick="return confirm('Apakah Anda benar-benar ingin keluar?')"><a href="../include/cek_login.php?op=out" class="top_link"><span>Logout</span></a></li>
    </li>
    <li><b>Welcome <?php echo "<font color='#FF0000'>".$id_user."</font>";?></b></li>
	</ul>
       <!-- akhir -->