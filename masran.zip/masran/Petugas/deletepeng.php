<?php

include "../include/koneksi.php";

$koneksi = mysql_connect($host,$user,$pass) or die (mysql_error());
if ($koneksi) {
mysql_select_db($db,$koneksi) or die (mysql_error());
}
$id_penghasilan= $_GET['id_penghasilan'];

$sql="delete from tb_penghasilan where id_penghasilan='$id_penghasilan'";
	
mysql_query($sql,$koneksi) or die ("Gagal Query simpan Ini Ya" .mysql_error());

include_once "penghasilan.php";

?>
