<?php 
	include "../include/koneksi.php";
	session_start();
	
	$userid = $_SESSION['username'];
	//cek level user
	if($_SESSION['level'] !="petugas"){header("Location:../include/previleges.php");}
?>

 
<?php

include_once "koneksi.php";
$NIS = $_GET['NIS'];
$NISN = $_POST['NISN'];
$nama_lengkap = $_POST['nama_lengkap'];
$jenis_kelamin = $_POST['jenis_kelamin'];
$id_kelas = $_POST['id_kelas'];
$tempat_lahir = $_POST['tempat_lahir'];
$tanggal_lahir = $_POST['tanggal_lahir'];
$bulan_lahir = $_POST['bulan_lahir'];
$tahun_lahir = $_POST['tahun_lahir'];
$lulusan_dari = $_POST['lulusan_dari'];
$id_agama = $_POST['id_agama'];
$nama_ayah = $_POST['nama_ortu'];
$id_pekerjaan_a = $_POST['id_pekerjaan'];
$alamat = $_POST['alamat'];

//jumlah


$koneksi = mysql_connect($host,$user,$pass) or die (mysql_error());
if ($koneksi) {
mysql_select_db($db,$koneksi) or die (mysql_error());

}
?>
<html>
<head>
<title>SMA Dharma Amiluhur</title>
<style type="text/css">
<!--
.style1 {color: #CCCCCC}
.style4 {color: #666666}
body {
	background-color: #FFFFFF;
}
-->
</style>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1"></head>

<body>
<table width="1105" border="0" align="center" bgcolor="#FFFFFF">
  <tr>
  <td width="1036">  </tr>
  <tr>
    <td><?php include"atasprint.php";?></td>
  </tr>
  
  
  
  <tr>
    <td><div align="center"><strong>View Data Siswa </strong></div></td>
  </tr>
  <tr>
    <td><form id="form2" name="form2" method="post" action="">
	
      <table width="1094" border="1" align="center">
        <tr bgcolor="#3399FF">
          <td width="20" bgcolor="#FFFFFF"><div align="center">No</div></td>
          <td width="27" bgcolor="#FFFFFF"><div align="center">NIS</div></td>
          <td width="38" bgcolor="#FFFFFF"><div align="center">NISN</div></td>
		  <td width="136" bgcolor="#FFFFFF"><div align="center">Nama Siswa</div></td>
          <td width="25" bgcolor="#FFFFFF"><div align="center">L/P</div></td>
          <td width="64" bgcolor="#FFFFFF"><div align="center">Kelas</div></td>
          <td width="69" bgcolor="#FFFFFF"><div align="center">Tempat Lahir </div></td>
          <td width="60" bgcolor="#FFFFFF"><div align="center">Tanggal Lahir </div></td>
          <td width="91" bgcolor="#FFFFFF"><div align="center">Asal SMP </div></td>
          <td width="64" bgcolor="#FFFFFF"><div align="center">Agama</div></td>
          <td width="92" bgcolor="#FFFFFF"><div align="center">Nama Ortu </div></td>
          <td width="109" bgcolor="#FFFFFF"><div align="center">Pekerjaan Ortu </div></td>
          <td width="217" bgcolor="#FFFFFF"><div align="center">Alamat </div></td>
          </tr>
        <tr>
		<?php
  			$sql = "SELECT s.NIS, NISN, nama_lengkap, jenis_kelamin, k.nama_kelas, tempat_lahir,
					tanggal_lahir, bulan_lahir, tahun_lahir, lulusan_dari, a.nama_agama,
					nama_ayah, nama_ibu, w.nama_wali, p.nama_pekerjaan, alamat
					FROM (((tb_siswa as s LEFT JOIN tb_kelas as k ON s.id_kelas = k.id_kelas) 
					LEFT JOIN tb_agama as a ON s.id_agama = a.id_agama) 
					LEFT JOIN tb_wali as w ON w.NIS = s.NIS)
					LEFT JOIN tb_pekerjaan as p ON s.id_pekerjaan_a = p.id_pekerjaan"; 
  //$sql="select * from tb_siswa order by NIS ASC";
  $qry= mysql_query($sql,$koneksi) or die ("Query Gagal ".mysql_error());
  $no=1;
  while($data=mysql_fetch_array($qry))
  {
  

$NIS = $data['NIS'];
$NISN = $data['NISN'];
$nama_lengkap = $data['nama_lengkap'];
$jenis_kelamin = $data['jenis_kelamin'];
$nama_kelas = $data['nama_kelas'];
$tempat_lahir = $data['tempat_lahir'];
$tanggal_lahir = $data['tanggal_lahir'];
$bulan_lahir = $data['bulan_lahir'];
$tahun_lahir = $data['tahun_lahir'];
$lulusan_dari = $data['lulusan_dari'];
$nama_agama = $data['nama_agama'];
$nama_ayah = $data['nama_ayah'];
$nama_pekerjaan = $data['nama_pekerjaan'];
$alamat = $data['alamat'];

?>
          <td><div align="center">
              <?php echo $no;?>
          </div></td>
          <td><div align="center"><?php echo $NIS;?></div></td>
		  <td><div align="center"><?php echo $NISN;?></div></td>
		  <td><div align="left"><?php echo $nama_lengkap;?></div></td>
          <td><div align="center"><?php echo $jenis_kelamin;?></div></td>
          <td><div align="left"><?php echo $nama_kelas;?></div></td>
          <td><div align="left"><?php echo $tempat_lahir;?></div></td>
          <td><div align="left"><?php echo $tanggal_lahir;?><?php echo $bulan_lahir;?><?php echo $tahun_lahir;?></div></td>
          
          <td><div align="center"><?php echo $lulusan_dari;?></div></td>
          <td><div align="left"><?php echo $nama_agama;?></div></td>
          <td><div align="left"><?php echo $nama_ayah;?></div></td>
		  <td><div align="left"><?php echo $nama_pekerjaan;?></div></td>
          <td><div align="left"><?php echo $alamat;?></div></td>
          </tr>
        
		<?php $no++; } ?>
      </table>
        </form>    </td>
  </tr>
  <tr>
    <td><div align="center"></div>      <div align="center"><a href="../dbdatasiswa/index2.php"></a><a href="../dbdatasiswa/index2.php"></a><a href="../dbdatasiswa/cetak.php"></a></div></td>
  </tr>
</table>
</body>
<script language="javascript">
window.print();
</script>
</html>
