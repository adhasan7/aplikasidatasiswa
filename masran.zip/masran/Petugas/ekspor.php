<?php 
	include "../include/koneksi.php";
	session_start();
	
	$id_user = $_SESSION['user_name'];
	//cek level user
	if($_SESSION['level']!="admin"){header("Location:../include/previleges.php");}
?>
<?php 
include "excel.php";
//query database untuk menampilkan data siswa
$queabsdetail = "SELECT * FROM tb_siswa order by NIS asc limit 0, 100";
$exequeabsdetail = mysql_query($queabsdetail);
while($res = mysql_fetch_array($exequeabsdetail)){



$agm_s=mysql_query("select * from `tb_agama` where `id_agama`='$res[id_agama]'");
$hagm_s=mysql_fetch_array($agm_s);

$kls_s=mysql_query("select * from `tb_kelas` where `id_kelas`='$res[id_kelas]'");
$hkls_s=mysql_fetch_array($kls_s);

$peker_a=mysql_query("select * from `tb_pekerjaan` where `id_pekerjaan`='$res[id_pekerjaan_a]'");
$hpeker_a=mysql_fetch_array($peker_a);

$wali=mysql_query("select * from `tb_wali` where `NIS`='$res[NIS]'");
$data_wali=mysql_fetch_array($wali);

$alamat_w=mysql_query("select * from `tb_wali` where `NIS`='$res[NIS]'");
$walamat=mysql_fetch_array($alamat_w);

$no_telp_w=mysql_query("select * from `tb_wali` where `NIS`='$res[NIS]'");
$telp_w=mysql_fetch_array($no_telp_w);

$peker_w=mysql_query("select * from `tb_pekerjaan` where `id_pekerjaan`='$data_wali[id_pekerjaan_w]'");
$hpeker_w=mysql_fetch_array($peker_w);

//mengambil data siswa dari database dimasukan ke array
$data['NIS'][] = $res['NIS'];
$data['NISN'][] = $res['NISN'];
$data['nama_lengkap'][] = $res['nama_lengkap'];
$data['jenis_kelamin'][] = $res['jenis_kelamin'];
$data['ttl'][] = $res['tempat_lahir'].', '.$res['tanggal_lahir'].' '.$res['bulan_lahir'].' '.$res['tahun_lahir'];
$data['agama_s'][] = $hagm_s['nama_agama'];
$data['lulusan_dari'][] = $res['lulusan_dari'];
$data['no_ijz'][] = $res['no_ijz'];
$data['no_SKHUN'][] = $res['no_SKHUN'];
$data['kelas_s'][] = $hkls_s['nama_kelas'];
$data['nama_ayah'][] = $res['nama_ayah'];
$data['alamat_a'][] = $res['alamat_a'];
$data['no_telp_a'][] = $res['no_telp_a'];
$data['pekerjaan_a'][] = $hpeker_a['nama_pekerjaan'];
$data['wali'][] = $data_wali['nama_wali'];
$data['no_telp_w'][] = $telp_w['no_telp_w'];
$data['pekerjaan_w'][] = $hpeker_w['nama_pekerjaan'];
$data['alamat_w'][] = $walamat['alamat_w'];


}
//untuk primary key table data_siswa yaitu id_siswa
$jm = sizeof($data['NIS']);
header("Pragma: public");
header("Expires: 0");
header("Cache-Control: must-revalidate, post-check=0, pre-check=0");
header("Content-Type: application/force-download");
header("Content-Type: application/octet-stream");
header("Content-Type: application/download");
header("Content-Disposition: attachment;filename=file_siswa.xls");
header("Content-Transfer-Encoding: binary");
xlsBOF();
/*
posisi excel berdasarkan baris dan kolom
diaplikasi posisinya berdasarkan nomor array dimulai dari 0
sedangkan di excel dimulai dari 1
ini untuk judul di excel. posisinya di baris array 0, kolom array 3
berarti posisi di excel 0 berarti baris 1, dan 3 berarti kolom 4
*/
xlsWriteLabel(0,7,"DATA SISWA");
/*
untuk nama2 field dimulai dari baris array 2(baris 3 di excel)
untuk kolomnya dimulai dari array 0(baris 1 di excel)
*/
xlsWriteLabel(2,0,"No");
xlsWriteLabel(2,1,"NIS" );
xlsWriteLabel(2,2,"NISN" );
xlsWriteLabel(2,3,"Nama Siswa" );
xlsWriteLabel(2,4,"Tempat Tanggal Lahir" );
xlsWriteLabel(2,5,"L/P" );
xlsWriteLabel(2,6,"Agama" );
xlsWriteLabel(2,7,"Kelas" );
xlsWriteLabel(2,8,"No Ijazah" );
xlsWriteLabel(2,9,"No SKHUN" );
xlsWriteLabel(2,10,"Asal SMP" );
xlsWriteLabel(2,11,"Nama Orang Tua" );
xlsWriteLabel(2,12,"Pekerjaan Orang Tua" );
xlsWriteLabel(2,13,"No. Telp Orang Tua" );
xlsWriteLabel(2,14,"Alamat Orang Tua" );
xlsWriteLabel(2,15,"Nama Wali" );
xlsWriteLabel(2,16,"Pekerjaan Wali" );
xlsWriteLabel(2,17,"No. Telp Wali" );
xlsWriteLabel(2,18,"Alamat Wali" );


/*
untuk mulai baris data (row) dimulai pada array 3(baris 4 di excel)
*/
$xlsRow = 3;
//untuk menampilkan data dari database di file excel
for ($y=0; $y<$jm; $y++) {
++$i;
xlsWriteNumber($xlsRow,0,"$i");
xlsWriteLabel($xlsRow,1,$data['NIS'][$y]);
xlsWriteLabel($xlsRow,2,$data['NISN'][$y]);
xlsWriteLabel($xlsRow,3,$data['nama_lengkap'][$y]);
xlsWriteLabel($xlsRow,4,$data['ttl'][$y]);
xlsWriteLabel($xlsRow,5,$data['jenis_kelamin'][$y]);
xlsWriteLabel($xlsRow,6,$data['agama_s'][$y]);
xlsWriteLabel($xlsRow,7,$data['kelas_s'][$y]);
xlsWriteLabel($xlsRow,8,$data['no_ijz'][$y]);
xlsWriteLabel($xlsRow,9,$data['no_SKHUN'][$y]);
xlsWriteLabel($xlsRow,10,$data['lulusan_dari'][$y]);
xlsWriteLabel($xlsRow,11,$data['nama_ayah'][$y]);
xlsWriteLabel($xlsRow,12,$data['pekerjaan_a'][$y]);
xlsWriteLabel($xlsRow,13,$data['no_telp_a'][$y]);
xlsWriteLabel($xlsRow,14,$data['alamat_a'][$y]);
xlsWriteLabel($xlsRow,15,$data['wali'][$y]);
xlsWriteLabel($xlsRow,16,$data['pekerjaan_w'][$y]);
xlsWriteLabel($xlsRow,17,$data['no_telp_w'][$y]);
xlsWriteLabel($xlsRow,18,$data['alamat_w'][$y]);

$xlsRow++;
}
xlsEOF();
exit();
?>