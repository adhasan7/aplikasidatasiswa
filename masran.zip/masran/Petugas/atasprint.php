<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<title>Data Lengkap Siswa</title></head>

<body>
<table width="773" border="0" align="center">
  <tr>
    <td width="109" rowspan="5"><div align="center"><img src="../css/images/gambar.jpg" width="91" height="115" /></div></td>
    <td><div align="center"></div></td>
    <td colspan="2">&nbsp;</td>
  </tr>
  <tr>
    <td><div align="center">YAYASAN KUNCUP SAMIGALUH </div></td>
    <td colspan="2">&nbsp;</td>
  </tr>
  <tr>
    <td width="602"><div align="center"><strong>SEKOLAH MENEMGAH KEJURUAN (SMK) KUNCUP </strong></div></td>
    <td width="48" colspan="2">&nbsp;</td>
  </tr>
  <tr>
    <td><div align="center">Alamat : Jl.Noto Sudiro No.1 Jetis, Gerbosari Samigaluh, Kulon Progo, Yogyakarta 55673 </div></td>
    <td colspan="2">&nbsp;</td>
  </tr>
  <tr>
    <td><div align="center">Telp : 082892674605 <a href="http://www.smadharmaamiluhur.sch.id/"></a>&nbsp;&nbsp;&nbsp;  E-Mail :  smkkuncupsamigaluh@ymail.com </div></td>
    <td colspan="2">&nbsp;</td>
  </tr>
</table>
</body>
</html>
