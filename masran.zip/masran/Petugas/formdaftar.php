<?php 
	include "../include/koneksi.php";
	session_start();
	
	$id_user = $_SESSION['user_name'];
	//cek level user
	if($_SESSION['level']!="petugas"){header("Location:../include/previleges.php");}
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>


<script type="text/javascript" src="jquery/jquery.min.js"></script>
		<script type="text/javascript" src="jquery/jquery.validate.min.js"></script>
		
		<script type="text/javascript">
		$(document).ready(function() {
			$('#form1').validate({
				rules: {
					NIS : {
						digits: true,
						minlength:3,
						maxlength:6
					},
					tgl: {
						indonesianDate:true
					},
					hp_siswa : {
						digits: true,
						minlength:12,
						maxlength:12
					},
					hp_wali : {
						digits: true,
						minlength:12,
						maxlength:12
					},
				},
				messages: {
					NIS: {
						required: "Kolom no induk harus diisi",
						minlength: "Kolom nim harus terdiri dari 3 digit",
						maxlength: "Kolom nim harus terdiri dari 6 digit"
					},
					email: {
						required: "Alamat email harus diisi",
						email: "Format email tidak valid"
					},
					nama: {
						required: "nama belum di isi"
						
					},
					tempat_lahir: {
						required: "Tempat Lahir belum di isi"
						
					},
					
					
				}
			});
		});
		
		$.validator.addMethod(
			"indonesianDate",
			function(value, element) {
				// put your own logic here, this is just a (crappy) example
				return value.match(/^\d\d?\/\d\d?\/\d\d\d\d$/);
			},
			"Please enter a date in the format DD/MM/YYYY"
		);
		</script>



  <?php include "atas.php";?>

    
		<!--- box border -->
<div id="lb">
		<div id="rb">
		<div id="bb"><div id="blc"><div id="brc">
		<div id="tb"><div id="tlc"><div id="trc">
		<!--  -->
				
		<div id="content">
    <td><div align="center"><table width="794" border="0" align="center">
  <tr>
  <td>  </tr>
  <tr>
    <td>&nbsp;</td>
  </tr>
  <tr>
    <td><form id="form1" name="form1" method="post" action="simpandaftar.php" enctype="multipart/form-data" >
      <table width="789" border="0">
        <tr>
          <td>&nbsp;</td>
          <td colspan="3"><div align="center" class="style3"><strong>Pengisian Data Siswa Baru </strong></div></td>
          <td width="158">&nbsp;</td>
        </tr>
        <tr>
          <td>&nbsp;</td>
          <td colspan="4"><?php
		if(isset($_GET['kosong']))
		{
			if($_GET['kosong']==1)
				echo "<font color='#FF0000'>Data Pada Bagian Siswa belum lengkap. Silahkan dilengkapi.
			</font>";

		}
		?></td>
        </tr>
        <tr>
          <td width="77">&nbsp;</td>
          <td colspan="4" bgcolor="#CCCCCC"><strong>A.IDENTITAS SISWA </strong>
              <label></label></td>
        </tr>
        <tr>
          <td>&nbsp;</td>
          <td width="145">NIS</td>
          <td width="10"><div align="center"><strong>:</strong></div></td>
          <td width="377"><input name="NIS" type="text" id="NIS" size="15" class="required" /></td>
          <td><input name="gambar" type="file" id="fieldField" value="Cari Foto" /></td>
        </tr>
        <tr>
          <td>&nbsp;</td>
          <td>Nama Siswa</td>
          <td><div align="center"><strong>:</strong></div></td>
          <td><label>
            <input name="nama_lengkap" type="text" id="nama" class="required"/>
          </label></td>
          <td>&nbsp;</td>
        </tr>
        <tr>
          <td>&nbsp;</td>
          <td>Jenis Kelamin</td>
          <td><div align="center"><strong>:</strong></div></td>
          <td>
            <input name="jenis_kelamin" type="radio" value="L" id="radiobutton" />
            L
            <input name="jenis_kelamin" type="radio" value="P" id="radiobutton"/>
            P </td>
          <td><label></label></td>
        </tr>
        <tr>
          <td>&nbsp;</td>
          <td>Tempat Lahir</td>
          <td><div align="center"><strong>:</strong></div></td>
          <td><label>
            <input type="text" name="tempat_lahir" id="tempat_lahir" class="required"/>
          </label></td>
          <td>&nbsp;</td>
        </tr>
        <tr>
          <td>&nbsp;</td>
          <td>Tanggal Lahir</td>
          <td><div align="center"><strong>:</strong></div></td>
           <td><input type="date" id="to" name="tgl_lahir" size="9" onClick="if(self.gfPop)gfPop.fPopCalendar(document.form1.to);return false;"/><a href="javascript:void(0)" onClick="if(self.gfPop)gfPop.fPopCalendar(document.form1.tgl_lahir);return false;" ><img name="popcal" align="center" style="border:none" src="./calender/calender.jpeg" width="34" height="29" border="0" alt=""></a> 
		   <iframe width=174 height=189 name="gToday:normal:calender/agenda.js" id="gToday:normal:calender/agenda.js" src="calender/ipopeng.htm" scrolling="no" frameborder="0" style="visibility:visible; z-index:999; position:absolute; top:-500px; left:500px;">
</iframe>
		   </td>

		</tr>
		
        <tr>
          <td>&nbsp;</td>
          <td>Kelas</td>
          <td><div align="center"><strong>:</strong></div></td>
          <td><select name="id_kelas" id="id_kelas">
              <option value="0" selected="selected">pilih</option>
              <?php
		  $sql="select * from tbl_kelas ";
		  $qry= mysql_query($sql);
		  
		  while ($data=mysql_fetch_array($qry)){
		  
		  echo"<option value='$data[kd_kelas]'> $data[kelas]</option>";
		  }
		  ?>
          
		  </td>
          <td>&nbsp;</td>
        </tr>
		
		<tr>
          <td>&nbsp;</td>
          <td>Agama</td>
          <td><div align="center"><strong>:</strong></div></td>
          <td><label>
            <select name="id_agama" id="id_agama">
              <option value="Notid_agama" selected="selected"> [---Agama---]</option>
              <?php
		  $sql="select kd_agama,agama from tbl_agama order by agama";
		  $qry= mysql_query($sql);
		  
		  while ($data=mysql_fetch_array($qry)){
		  if ($data[kd_agama]==$id_agama){
		  $cek1="selected";
		  }
		  else
		  {
		  $cek1="";
		  }
		  echo"<option value='$data[kd_agama]' $cek> $data[agama]</option>";
		  }
		  ?>
            </select>
          </label></td>
          <td>&nbsp;</td>
        </tr>
        <tr>
          <td>&nbsp;</td>
          <td>No. Telp </td>
          <td><div align="center"><strong>:</strong></div></td>
          <td><label>
            <input type="text" name="no_telp" id="hp_siswa" class="required"/>
          </label></td>
          <td>&nbsp;</td>
        </tr>

		
		<tr>
          <td>&nbsp;</td>
          <td>Anak ke </td>
          <td><div align="center"><strong>:</strong></div></td>
          <td><label>
            <input type="text" size="5" name="anak_ke" id="anak_ke"/>
          </label></td>
          <td>&nbsp;</td>
        </tr>
        <tr>
          <td>&nbsp;</td>
          <td>Jumlah saudara kandung </td>
          <td><div align="center"><strong>:</strong></div></td>
          <td><label>
            <input type="text" size="5" name="jumlah_saudara_kandung" id="jlm_sdr" />
          </label></td>
          <td>&nbsp;</td>
        </tr>
       <tr>
          <td>&nbsp;</td>
          <td>Nama Sekolah </td>
          <td><div align="center"><strong>:</strong></div></td>
          <td><select name="id_sekolah" id="id_sekolah">
              <option value="Notid_pekerjaan_a" selected="selected"> [---pilih---]</option>
              <?php
		  $sql="select kd_sekolah,nama_sekolah from tbl_asal_sekolah order by nama_sekolah";
		  $qry= mysql_query($sql);
		  
		  while ($data=mysql_fetch_array($qry)){
		  if ($data[kd_sekolah]==$id_sekolah){
		  $cek1="selected";
		  }
		  else
		  {
		  $cek1="";
		  }
		  echo"<option value='$data[kd_sekolah]' $cek> $data[nama_sekolah]</option>";
		  }
		  ?>
            </select>          </td>
   <td>&nbsp;</td>
        </tr>
        <tr>
          <td>&nbsp;</td>
          <td>Alamat Lengkap</td>
          <td><div align="center"><strong>:</strong></div></td>
          <td><label></label>
              <label for="textarea"></label>
              <label for="textfield"></label>
              <textarea name="alamat"></textarea></td>
          <td>&nbsp;</td>
        </tr>
		<tr>
          <td>&nbsp;</td>
          <td>Tahun Masuk</td>
          <td><div align="center"><strong>:</strong></div></td>
          <td><select name="id_tahun_ajar" id="id_tahun_ajar">
              <option value="tahun_ajar" selected="selected"> [---pilih---]</option>
              <?php
		  $sql="select kd_tahun_ajar,tahun_ajar from tbl_tahun_ajar order by tahun_ajar";
		  $qry= mysql_query($sql);
		  
		  while ($data=mysql_fetch_array($qry)){
		  if ($data[kd_tahun_ajar]==$id_tahun_ajar){
		  $cek1="selected";
		  }
		  else
		  {
		  $cek1="";
		  }
		  echo"<option value='$data[kd_tahun_ajar]' $cek> $data[tahun_ajar]</option>";
		  }
		  ?>
            </select>          </td>
   <td>&nbsp;</td>
        </tr>
		
        <tr>
          <td>&nbsp;</td>
          <td>Status Masuk</td>
          <td><div align="center"><strong>:</strong></div></td>
          <td>
            <input name="status_masuk" type="radio" value="Fresh" id="radiobutton" />
            Fresh
            <input name="status_masuk" type="radio" value="Pindahan" id="radiobutton"/>
            Pindahan </td>
          <td><label></label></td>
        </tr>
		
		<tr>
          <td>&nbsp;</td>
          <td>&nbsp;</td>
          <td>&nbsp;</td>
          <td>&nbsp;</td>
        </tr>
        <tr>
			<td>&nbsp;</td>
          <td colspan="4" bgcolor="#CCCCCC"><strong>B. DATA ORANG TUA/WALI</strong></td>
          </tr>
        <tr>
          <td>&nbsp;</td>
          <td>Nama </td>
          <td><div align="center"><strong>:</strong></div></td>
          <td><label>
            <input type="text" name="nama_wali" id="nama_wali" class="required"/>
          </label></td>
        </tr>
        <tr>
          <td>&nbsp;</td>
          <td>Agama</td>
          <td><div align="center"><strong>:</strong></div></td>
          <td><select name="agama_wali" id="gama_wali">
              <option value="Notid_agama_a" selected="selected"> [---Agama---]</option>
              <?php
		  $sql="select kd_agama,agama from tbl_agama order by agama";
		  $qry= mysql_query($sql);
		  
		  while ($data=mysql_fetch_array($qry)){
		  if ($data[kd_agama]==$id_agama){
		  $cek1="selected";
		  }
		  else
		  {
		  $cek1="";
		  }
		  echo"<option value='$data[kd_agama]' $cek> $data[agama]</option>";
		  }
		  ?>
          </select></td>
        </tr>
        <tr>
          <td>&nbsp;</td>
          <td>Kewarganegaraan</td>
          <td><div align="center"><strong>:</strong></div></td>
          <td><input name="kewarganegaraan" type="radio" value="WNI" id="radiobutton" />
            WNI
            <input name="kewarganegaraan" type="radio" value="WNA" id="radiobutton"/>
            WNA</td>
        </tr>
		
		 <tr>
          <td>&nbsp;</td>
          <td>Tingkat Pendidikan</td>
          <td><div align="center"><strong>:</strong></div></td>
          <td><input name="tingkat_pendidikan" type="radio" value="SD" id="radiobutton" />
            SD
            <input name="tingkat_pendidikan" type="radio" value="SMP" id="radiobutton"/>
            SMP
			<input name="tingkat_pendidikan" type="radio" value="SMA" id="radiobutton"/>
            SMA
			<input name="tingkat_pendidikan" type="radio" value="Sarjana" id="radiobutton"/>
            Sarjana</td>
        </tr>
		
        <tr>
          <td>&nbsp;</td>
          <td>Pekerjaan</td>
          <td><div align="center"><strong>:</strong></div></td>
          <td><select name="id_pekerjaan" id="pekerjaan_wali">
              <option value="Notid_pekerjaan" selected="selected"> [---pilih---]</option>
              <?php
		  $sql="select kd_pekerjaan,pekerjaan from tbl_pekerjaan order by pekerjaan";
		  $qry= mysql_query($sql);
		  
		  while ($data=mysql_fetch_array($qry)){
		  if ($data[kd_pekerjaan]==$id_pekerjaan){
		  $cek1="selected";
		  }
		  else
		  {
		  $cek1="";
		  }
		  echo"<option value='$data[kd_pekerjaan]' $cek> $data[pekerjaan]</option>";
		  }
		  ?>
            </select>          </td>
        </tr>
        <tr>
          <td>&nbsp;</td>
          <td>Alamat</td>
          <td><div align="center"><strong>:</strong></div></td>
          <td><textarea name="alamat_wali" required=""></textarea></td>
        </tr>
        <tr>
          <td>&nbsp;</td>
          <td>No. Telp </td>
          <td><div align="center"><strong>:</strong></div></td>
          <td><input type="text" name="no_telp_wali" id="hp_wali" class="required"/></td>
        </tr>
        
        
        
        <tr>
          <td>&nbsp;</td>
          <td>&nbsp;</td>
          <td>&nbsp;</td>
          <td>&nbsp;</td>
        </tr>
        <tr>
          <td>&nbsp;</td>
          <td>&nbsp;</td>
          <td>&nbsp;</td>
          <td><label>
            <input type="submit" name="Submit" value="Simpan" />
            <input type="submit" value="Batal" onclick="viewsiswa.php" />
          </label></td>
        </tr>
      </table>
    </form> 
	
	   </td>
  </tr>
</table>
        </form>    </td>
    </div>
		
		<!--- end of box border -->
		</div></div></div></div>
		</div></div></div></div>
		<!-- -->
			<?php include "../css/footer.php"; ?></body>
			

</html>