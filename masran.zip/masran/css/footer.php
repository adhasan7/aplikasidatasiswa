<div id="footer">
<div id="footerkiri">
<a href="http://fti.mercubuana-yogya.ac.id/" target="_blank" >FTI Mercu Buana Yogyakarta</a></div>
<div id="footerkanan">

</div>
</div>
</body>
</html>
