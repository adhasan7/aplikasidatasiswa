<style type="text/css">
<!--
#Layer1 {
	position:absolute;
	left:761px;
	top:20px;
	width:253px;
	height:244px;
	z-index:1;
}
.style15 {
	font-family: "Courier New", Courier, monospace;
	font-size: x-small;
}
.style17 {
	font-size: small;
	font-weight: bold;
	font-style: italic;
}
.style22 {font-family: "Courier New", Courier, monospace; font-size: large; }
-->
</style>
<h2 align="justify" class="style15">
  <p h2="h2" align="left">&nbsp;</p>
</h2>
<h2 align="justify" class="style22">Aplikasi ini merupakan database Biodata Siswa SMK YPPN Sleman. Tujuan dari Aplikasi ini adalah untuk mempermudah dalam pengolahan dan penyimpanan Biodata Siswa agar lebih efektif dan efisien.<br />
Content yang tersedia di Aplikasi ini adalah sebagai berikut:</h2>
<span class="style15"></span><span class="style15">
<h2 align="justify" class="style17">Profil Singkat SMK YPPN Sleman <br />
  Input Data Siswa <br />
  Hapus Data Siswa<br />
  Edit Data Siswa <br />
  Input Gambar <br />
  Eksport Data Dalam Excel</h2>
</span>
<h2 align="justify" class="style22">Semoga aplikasi ini dapat dimanfaatkan sebaik mungkin.<br />
  Terima Kasih dan Sukses Selalu</h2>
