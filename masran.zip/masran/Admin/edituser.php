<?php
error_reporting(E_ALL && E_DEPRECATED ^ E_NOTICE);
include "../include/koneksi.php";
session_start();

$id_user = $_SESSION['admin_username'];
	//cek level user
	if($_SESSION['level']!="admin"){header("Location:../include/previleges.php");}

  $admin_username=$_SESSION["admin_username"];
  if(empty($admin_username)){
    header("location:../index.php");
    exit();
  }

$admin_id = $_GET['admin_id'];
	
$sql = "select * from tbl_admin where admin_id='$admin_id' ";
$qry = mysql_query($sql,$koneksi) or die ("Query Gagal ".mysql_error());	
while($data=mysql_fetch_array($qry))
{
$user_name=$data['admin_username'];
$pass=$data['admin_password'];
$level=$data['admin_level'];
}


?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
  <?php include "atas.php";?>

    
		<!--- box border -->
		<div id="lb">
		<div id="rb">
		<div id="bb"><div id="blc"><div id="brc">
		<div id="tb"><div id="tlc"><div id="trc">
		<!--  -->
				
		<div id="content">
    <td><div align="center" class="notd"></div></td>
  </tr>
  <tr>
    <td >&nbsp;</td>
  </tr>
  <tr>

         <td height="292">   
         <td colspan="6"><table width="785" border="0" align="center">
           <tr>
             <td><div align="center"><strong>EDIT USER </strong></div></td>
           </tr>
           <tr>
             <td><form action="updateuser.php" method="post" name="form1" id="form1">
               <table width="379" border="0" align="center">
                 <tr>
                   <td>User Name </td>
                   <td><div align="center">:</div></td>
                   <td><label>
                     <input name="admin_username" type="text" id="user_name" value="<?php echo $user_name;?>" size="25" maxlength="25" />
					 <?php echo $user_name; ?>
                   </label></td>
                 </tr>
                 <tr>
                   <td>Password</td>
                   <td align="center"><div align="center">:</div></td>
                   <td><label>
                     <input name="admin_password" type="password" id="pass"  value="<?php echo $pass;?>" />
                   </label></td>
                 </tr>                 
                 <tr>
                   <td height="21">&nbsp;</td>
                   <td>&nbsp;</td>
                   <td>&nbsp;</td>
                 </tr>
                 <tr>
                 <input type="hidden" name="admin_id" value="<?php echo $admin_id;?>"> 
                   <td colspan="3" align="center"><input name="Submit" type="submit" id="Submit" value="Update" /></td>
                 </tr>
               </table>
               <div align="center"></div>
             </form></td>
           </tr>
         </table></td>
  </tr>
</table>
  
    </div>
		
		<!--- end of box border -->
		</div></div></div></div>
		</div></div></div></div>
		<!-- -->
	<?php include "../css/footer.php"; ?>		
</div>
</body>
</html>