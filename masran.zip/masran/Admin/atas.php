<?php 
error_reporting(E_ALL && E_DEPRECATED ^ E_NOTICE);
		include "../include/koneksi.php";
		session_start();		
?>
<!-- awal -->
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
<title>SMK YPPN SLEMAN</title>
<link rel="stylesheet" href="../css/border.css" media="screen">
<link rel="stylesheet" type="text/css" href="../css/drop/pro_drop_1.css" />
<link rel="shotcut icon" href="../css/images/logoc.png" />

</head>
<body style="margin:0px;" background="../image/image1.jpg">

<div id="header">
	<img src="../css/images/header.jpg" width="955" height="153" style="float:left; margin-left:20px"/>
</div>

<div id="box" style="margin-top:0px;">
	<ul id="nav">
   	<li class="top"><a href="index.php" class="top_link"><span>Home</span></a></li>
    
    <li class="top"><a href="#" id="products" class="top_link"><span class="down">Data Master</span></a>
    	<ul class="sub">
			<li><a href="viewsiswa.php">Siswa</a></li>
			<li><a href="kelas.php">Kelas</a></li>			
			<li><a href="pekerjaan.php">Pekerjaan</a></li>			
    </li>
		</ul>
        
    </li>
	
    
	 
    <li class="top"><a href="#" id="products" class="top_link"><span class="down">Kelas</span></a>
        <ul class="sub">
		 <?php
	 include "../include/koneksi.php";
	 
        $sql = mysql_query("SELECT * from tbl_kelas");
        while($r=mysql_fetch_array($sql)) {
		$id_kelas=$r['kelas_id'];
 
            echo "<li><a href='list_perkelas.php?id_kelas=$id_kelas'>".$r['kelas_nama']."</a>";
 
             echo "</li>";
            }
    ?>
		
		
         </ul>
	</li>	
	
	
	<li class="top"><a href="rekap_tmp.php" id="products" class="top_link"><span>Rekap</span></a></li>

	<li class="top"><a href="carisiswa1.php" id="products" class="top_link"><span>Cari</span></a></li>
	
	<li class="top"><a href="user.php" id="products" class="top_link"><span>user</span></a></li>
	 
	<li class="top"><a href="profil.php" class="top_link"><span>About</span></a></li>		
    
	<li class="top" onClick="return confirm('Apakah Anda benar-benar ingin keluar?')"><a href="../include/cek_login.php?op=out" class="top_link"><span>Logout</span></a></li>
    </li>
    <?php 
    	$admin_username=$_SESSION['admin_username'];
    	echo "<h2>$admin_id</h2></hr>";
    	$query="SELECT * FROM tbl_admin WHERE admin_username='$admin_username'";
    	$hasil=mysql_query($query) or die(mysql_error());
    	$admin_nama="Tidak tersedia";
    	if($hasil){
    		while($x=mysql_fetch_array($hasil)){
    			$admin_nama=$x[1];
    		}
    	}
    ?>
    <li><b>Welcome <?php echo "<font color='#FF0000'>".$admin_nama."</font>";?></b></li>
	</ul>
       <!-- akhir -->