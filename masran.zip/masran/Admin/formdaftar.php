<?php 
error_reporting(E_ALL && E_DEPRECATED ^ E_NOTICE);
	include "../include/koneksi.php";
	session_start();
	
	$id_user = $_SESSION['user_name'];
	//cek level user
	if($_SESSION['level']!="admin"){header("Location:../include/previleges.php");}
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>


<script type="text/javascript" src="jquery/jquery.min.js"></script>
		<script type="text/javascript" src="jquery/jquery.validate.min.js"></script>
		
		<script type="text/javascript">
		$(document).ready(function() {
			$('#form1').validate({
				rules: {
					NIS : {
						digits: true,
						minlength:3,
						maxlength:6
					},
					tgl: {
						indonesianDate:true
					},
					hp_siswa : {
						digits: true,
						minlength:12,
						maxlength:12
					},
					hp_wali : {
						digits: true,
						minlength:12,
						maxlength:12
					},
				},
				messages: {
					NIS: {
						required: "Kolom no induk harus diisi",
						minlength: "Kolom nis harus terdiri dari 3 digit",
						maxlength: "Kolom nis harus terdiri dari 6 digit"
					},
					email: {
						required: "Alamat email harus diisi",
						email: "Format email tidak valid"
					},
					nama: {
						required: "nama belum di isi"
						
					},
					tempat_lahir: {
						required: "Tempat Lahir belum di isi"
						
					},
					
					
				}
			});
		});
		
		$.validator.addMethod(
			"indonesianDate",
			function(value, element) {
				// put your own logic here, this is just a (crappy) example
				return value.match(/^\d\d?\/\d\d?\/\d\d\d\d$/);
			},
			"Please enter a date in the format DD/MM/YYYY"
		);
		</script>



  <?php include "atas.php";?>

    
		<!--- box border -->
<div id="lb">
		<div id="rb">
		<div id="bb"><div id="blc"><div id="brc">
		<div id="tb"><div id="tlc"><div id="trc">
		<!--  -->
				
		<div id="content">
    <td><div align="center"><table width="794" border="0" align="center">
  <tr>
  <td>  </tr>
  <tr>
    <td>&nbsp;</td>
  </tr>
  <tr>
    <td><form id="form1" name="form1" method="post" action="simpandaftar.php" enctype="multipart/form-data" >
      <table width="789" border="0">
        <tr>
          <td>&nbsp;</td>
          <td colspan="3"><div align="center" class="style3"><strong>Pengisian Data Siswa Baru </strong></div></td>
          <td width="158">&nbsp;</td>
        </tr>
        <tr>
          <td>&nbsp;</td>
          <td colspan="4"><?php
		if(isset($_GET['kosong']))
		{
			if($_GET['kosong']==1)
				echo "<font color='#FF0000'>Data Pada Bagian Siswa belum lengkap. Silahkan dilengkapi.
			</font>";

		}
		?></td>
        </tr>
        <tr>
          <td width="77">&nbsp;</td>
          <td colspan="4" bgcolor="#CCCCCC"><strong>A.IDENTITAS SISWA </strong>
              <label></label></td>
        </tr>
        <tr>
          <td>&nbsp;</td>
          <td width="145">NIS</td>
          <td width="10"><div align="center"><strong>:</strong></div></td>
          <td width="377"><input name="siswa_nis" type="text" id="NIS" size="15" class="required" /></td>
          <td><input name="gambar" type="file" id="fieldField" value="Cari Foto" /></td>
        </tr>
        <tr>
          <td>&nbsp;</td>
          <td width="145">NISN</td>
          <td width="10"><div align="center"><strong>:</strong></div></td>
          <td width="377"><input name="siswa_nisn" type="text" id="NISN" size="15" class="required" /></td>
        </tr>
        <tr>
          <td>&nbsp;</td>
          <td width="145">NIK</td>
          <td width="10"><div align="center"><strong>:</strong></div></td>
          <td width="377"><input name="siswa_nik" type="text" id="NIK" size="20" class="required" /></td> 
        </tr>

        <tr>
          <td>&nbsp;</td>
          <td>Nama Siswa</td>
          <td><div align="center"><strong>:</strong></div></td>
          <td><label>
            <input name="siswa_nama" type="text" id="nama" class="required"/>
          </label></td>
          <td>&nbsp;</td>
        </tr>
        <tr>
          <td>&nbsp;</td>
          <td>Jenis Kelamin</td>
          <td><div align="center"><strong>:</strong></div></td>
          <td>
            <input name="siswa_jk" type="radio" value="L" id="radiobutton" />
            L
            <input name="siswa_jk" type="radio" value="P" id="radiobutton"/>
            P </td>
          <td><label></label></td>
        </tr>
        <tr>
          <td>&nbsp;</td>
          <td>Tempat Lahir</td>
          <td><div align="center"><strong>:</strong></div></td>
          <td><label>
            <input type="text" name="siswa_tempat_lahir" id="tempat_lahir" class="required"/>
          </label></td>
          <td>&nbsp;</td>
        </tr>
        <tr>
          <td>&nbsp;</td>
          <td>Tanggal Lahir</td>
          <td><div align="center"><strong>:</strong></div></td>
           <td><input type="date" id="to" name="siswa_tgl_lahir" size="9" onClick="if(self.gfPop)gfPop.fPopCalendar(document.form1.to);return false;"/><a href="javascript:void(0)" onClick="if(self.gfPop)gfPop.fPopCalendar(document.form1.tgl_lahir);return false;" ><img name="popcal" align="center" style="border:none" src="./calender/calender.jpeg" width="34" height="29" border="0" alt=""></a> 
		   <iframe width=174 height=189 name="gToday:normal:calender/agenda.js" id="gToday:normal:calender/agenda.js" src="calender/ipopeng.htm" scrolling="no" frameborder="0" style="visibility:visible; z-index:999; position:absolute; top:-500px; left:500px;">
</iframe>
		   </td>

		</tr>
		
        <tr>
          <td>&nbsp;</td>
          <td>Kelas</td>
          <td><div align="center"><strong>:</strong></div></td>
          <td><select name="siswa_kelas" id="id_kelas">
              <option value="0" selected="selected">pilih</option>
              <?php
		  $sql="select * from tbl_kelas ";
		  $qry= mysql_query($sql);
		  
		  while ($data=mysql_fetch_array($qry)){
		  
		  echo"<option value='$data[0]'> $data[1]</option>";
		  }
		  ?>
          
		  </td>
          <td>&nbsp;</td>
        </tr>
		

        <tr>
          <td>&nbsp;</td>
          <td>Alamat Lengkap</td>
          <td><div align="center"><strong>:</strong></div></td>
          <td><label></label>
              <label for="textarea"></label>
              <label for="textfield"></label>
              <textarea name="siswa_alamat"></textarea></td>
          <td>&nbsp;</td>
        </tr>
		
		
       
		
		<tr>
          <td>&nbsp;</td>
          <td>&nbsp;</td>
          <td>&nbsp;</td>
          <td>&nbsp;</td>
        </tr>
        <tr>
			<td>&nbsp;</td>
          <td colspan="4" bgcolor="#CCCCCC"><strong>B. DATA ORANG TUA</strong></td>
          </tr>
        <tr>
          <td>&nbsp;</td>
          <td>Nama Bapak</td>
          <td><div align="center"><strong>:</strong></div></td>
          <td><label>
            <input type="text" name="siswa_ayah" id="nama_bapak" class="required"/>
          </label></td>
        </tr>       
		<tr>
          <td>&nbsp;</td>
          <td>&nbsp;</td>
          <td>&nbsp;</td>
          <td>&nbsp;</td>
        </tr>
        
        <tr>
          <td>&nbsp;</td>
          <td>Nama Ibu</td>
          <td><div align="center"><strong>:</strong></div></td>
          <td><label>
            <input type="text" name="siswa_ibu" id="nama_ibu" class="required"/>
          </label></td>
        </tr>
        <tr>
          <td>&nbsp;</td>
          <td>Pekerjaan</td>
          <td><div align="center"><strong>:</strong></div></td>
          <td><select name="siswa_pekerjaan_ortu" id="pekerjaan_ibu">
              <option value="Notid_pekerjaan" selected="selected"> [---pilih---]</option>
              <?php
		  $sql="select pekerjaan_id,pekerjaan_nama from tbl_pekerjaan order by pekerjaan_id";
		  $qry= mysql_query($sql);
		  
		  while ($data=mysql_fetch_array($qry)){
		  if ($data[0]==$id_pekerjaan){
		  $cek1="selected";
		  }
		  else
		  {
		  $cek1="";
		  }
		  echo"<option value='$data[0]' $cek> $data[1]</option>";
		  }
		  ?>
            </select>          </td>
        </tr>     
		<tr>
          <td>&nbsp;</td>
          <td>&nbsp;</td>
          <td>&nbsp;</td>
          <td>&nbsp;</td>
        </tr>
          
		<tr>
          <td>&nbsp;</td>
          <td>&nbsp;</td>
          <td>&nbsp;</td>
          <td>&nbsp;</td>
        </tr>
        
       
        
        <tr>
          <td>&nbsp;</td>
          <td>&nbsp;</td>
          <td>&nbsp;</td>
          <td><label>
            <input type="submit" name="Submit" value="Simpan" />
            <input type="submit" value="Batal" onclick="viewsiswa.php" />
          </label></td>
        </tr>
      </table>
    </form> 
	
	   </td>
  </tr>
</table>
        </form>    </td>
    </div>
		
		<!--- end of box border -->
		</div></div></div></div>
		</div></div></div></div>
		<!-- -->
			<?php include "../css/footer.php"; ?></body>
			

</html>