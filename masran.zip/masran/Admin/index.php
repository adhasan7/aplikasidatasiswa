<?php 
error_reporting(E_ALL && E_DEPRECATED ^ E_NOTICE);
	include "../include/koneksi.php";
	session_start();
	
	$id_user = $_SESSION['user_name'];
	//cek level user
	if($_SESSION['level']!="admin"){header("Location:../include/previleges.php");}
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
  <?php include "atas.php";?>
  	   
		<!--- box border -->
		<style type="text/css">
<!--
.style1 {font-weight: bold}
-->
</style><div id="lb">
		<div id="rb">
		<div id="bb"><div id="blc"><div id="brc">
		<div id="tb"><div id="tlc"><div id="trc">
		<!--  -->
				
		<div id="content">
		  <table width="767" border="0">
            <tr>
              <td bgcolor="#CCCCCC"><div align="center" class="style20">
                <div align="left"><strong>Informasi Sekolah </strong></div>
              </div></td>
            </tr>
            <tr>
              <td><div align="center" class="style20">
                <div align="left">Nama Sekolah : SMK YPPN Sleman<br />
                  Nomor Statistik Sekolah : 322 04 02 12 013<br />
                  Alamat  : Jl. Damai, Dayu, Sinduharjo, Ngaglik, Sleman, Daerah Istimewa Yogyakarta<br />
                  Telepon : (0274) 884003<br />
                  E-mail : smkyppnsleman@gmail.com<br />
                  Status sekolah :  Swasta <br />
                  Nama Yayasan : Yayasan Pembangunan Pengabdi <br />
                  No. Akte Pendirian : 112/I 13/H/Kpts/96 Tanggal 1 April 1996<br />
                  Tahun Berdiri Sekolah : 1996<br />
                   Status Akreditasi :  B</div>
              </div></td>
              </div></td>
            </tr>
            <tr>
              <td bgcolor="#CCCCCC"><div align="center" class="style20">
                <div align="left"><strong>VISI</strong></div>
              </div></td>
            </tr>
            <tr>
              <td>
                Menyiapkan lulusan yang bertaqwa , keterampilan , handal dan profesional dalam bidang otomotif , yang mampu bersaing dalam memenuhi kebutuhan tenaga kerja di era global.                                                        
              </td>
            </tr>
            <tr>
              <td bgcolor="#CCCCCC"><div align="center" class="style20">
                <div align="left"><strong>MISI</strong></div>
              </div></td>
            </tr>
            <tr>
              <td>
                <div align="center" class="style20">
                  <div align="left">
                1. Mendidik dan mengembangkan kepribadian para siswa yang berakhlak mulia sesuai latar belakang agama nya.<br/>
                2. Pelaksanaan kegiatan belajar mengajar yang berkualitas baik di sekolah maupun di dunia usaha/dunia industri.<br/>
                3. Meningkatkan sarana pendidikan sesuai dengan perkembangan IPTEK.<br/>
                4. Menciptakan iklim kerja yang kondusif melalui pelaksanaan 7K.<br/>
                5. Mendidik para siswa agar setelah tamat mampu mandiri dan berkompetensi di pasar kerja
                </div></td>
            </tr>
          </table>
		</div>
		
		
		<!--- end of box border -->
		</div>
		</div></div></div>
			
		</div></div></div></div>
		<!-- -->
		<?php include "../css/footer.php"; ?>
</div>


</body>
</html>