<?php
error_reporting(E_ALL && E_DEPRECATED ^ E_NOTICE);

	include "../include/koneksi.php";

$koneksi = mysql_connect($host,$user,$pass) or die (mysql_error());
if ($koneksi) {
mysql_select_db($db,$koneksi) or die (mysql_error());

$siswa_nis=$_POST["siswa_nis"];
$siswa_nama=$_POST["siswa_nama"];
$siswa_tempat_lahir=$_POST["siswa_tempat_lahir"];
$siswa_tgl_lahir=$_POST["siswa_tgl_lahir"];
$siswa_jk=$_POST["siswa_jk"];
$siswa_alamat=$_POST["siswa_alamat"];
$siswa_ayah=$_POST["siswa_ayah"];
$siswa_ibu=$_POST["siswa_ibu"];
$siswa_pekerjaan_ortu=$_POST["siswa_pekerjaan_ortu"];
$siswa_kelas=$_POST["siswa_kelas"];


$siswa="UPDATE tbl_siswa SET siswa_nis='$siswa_nis'
,siswa_nama='$siswa_nama'
,siswa_tempat_lahir='$siswa_tempat_lahir'
,siswa_tgl_lahir='$siswa_tgl_lahir'
,siswa_jk='$siswa_jk'
,siswa_alamat='$siswa_alamat'
,siswa_ayah='$siswa_ayah'
,siswa_ibu='$siswa_ibu'
,siswa_pekerjaan_ortu='$siswa_pekerjaan_ortu'
,siswa_kelas='$siswa_kelas' WHERE siswa_nis='$siswa_nis'";
	
mysql_query($siswa,$koneksi) or die ("Gagal Query Update Siswa Ya" .mysql_error());

include_once "viewsiswa.php";

}

?>