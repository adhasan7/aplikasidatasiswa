<?php
error_reporting(E_ALL && E_DEPRECATED ^ E_NOTICE);

include "../include/koneksi.php";

$koneksi = mysql_connect($host,$user,$pass) or die (mysql_error());
if ($koneksi) {
mysql_select_db($db,$koneksi) or die (mysql_error());

$kode_sekolah=$_POST['kode_sekolah'];
$nama_sekolah= $_POST['nama_sekolah'];
$alamat_sekolah= $_POST['alamat_sekolah'];


$sql="insert into tbl_asal_sekolah (asek_nama,asek_alamat) values('$nama_sekolah','$alamat_sekolah')";
	
		
mysql_query($sql,$koneksi) or die ("Gagal Query simpan data sekolah" .mysql_error());

include_once "asal_sekolah.php";
}

?>