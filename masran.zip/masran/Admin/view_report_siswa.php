<?php 
error_reporting(E_ALL && E_DEPRECATED ^ E_NOTICE);
include "../include/koneksi.php";
session_start();

$id_user = $_SESSION['user_name'];
	//cek level user
	if($_SESSION['level']!="admin"){header("Location:../include/previleges.php");
}
$NIS = $_GET['NIS'];

$kelas="0";
$pekerjaan="not available";
$qry=mysql_query("select * from tbl_siswa where siswa_nis='$NIS'");

$siswa_nisn="not available";
$siswa_nis="not available";
$siswa_nik="not available";
$siswa_nama="not available";
$siswa_tempat_lahir="not available";
$siswa_tgl_lahir="not available";
$siswa_jk="not available";
$siswa_alamat="not available";
$siswa_ayah="not available";
$siswa_ibu="not available";
$siswa_pekerjaan_ortu="not available";
$siswa_kelas="not available";

while($x=mysql_fetch_array($qry)){
  $siswa_nisn=$x[0];
  $siswa_nis=$x[1];
  $siswa_nik=$x[2];
  $siswa_nama=$x[3];
  $siswa_tempat_lahir=$x[4];
  $siswa_tgl_lahir=$x[5];
  $siswa_jk=$x[6];
  $siswa_alamat=$x[7];
  $siswa_ayah=$x[8];
  $siswa_ibu=$x[9];
  $siswa_pekerjaan_ortu=$x[10];
  $siswa_kelas=$x[11]; 
}

$kls_s=mysql_query("select * from `tbl_kelas` where `kelas_id`='$siswa_kelas'");
$res=mysql_fetch_array($kls_s);
if($res){
  while($x=mysql_fetch_array($res)){
    $siswa_kelas=$x[1];
  }
}

$pek_s=mysql_query("select * from `tbl_pekerjaan` where `pekerjaan_id`='$siswa_pekerjaan_ortu'");
$res=mysql_fetch_array($pek_s);
if($res){
  while($x=mysql_fetch_array($res)){
    $siswa_pekerjaan_ortu=$x[1];
  }
}

?>

<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>

  <?php include "atasprint.php";?>
    			
		<title>Data Lengkap Siswa</title><div id="content">
          <td><div align="center">
              <table width="845" border="0" align="center">
                <tr>
                  <td></td>
                </tr>

                <tr>
                  <td></td>
                </tr>
                <tr>
                  <td>&nbsp;</td>
                  <td colspan="4"><div align="center" class="style3"><strong>View Data Siswa </strong></div></td>
                </tr>
                <tr>
                  <td>&nbsp;</td>
                  <td>&nbsp;</td>
                </tr>

                <tr>
                  <td width="52">&nbsp;</td>
                  <td colspan="4" bgcolor="#CCCCCC"><strong>A.IDENTITAS SISWA </strong>
                      <label></label><div align="center"></div></td>
                </tr>
                <tr>
                  <td>&nbsp;</td>
                  <td width="165">NIS</td>
                  <td width="5"><div align="center"><strong>:</strong></div></td>
                  <td width="440"><?php echo $NIS;?></td>
                  <td rowspan="8"><div align="left"><img src="../foto_siswa/<?php echo $gambar;?>" hspace="0" border="0" height="48%" width="56%" /></div></td>
                </tr>
                <tr>
                  <td>&nbsp;</td>
                  <td>Nama Siswa</td>
                  <td><div align="center"><strong>:</strong></div></td>
                  <td><label><?php echo $siswa_nama;?></label></td>
			    </tr>
                <tr>
                  <td>&nbsp;</td>
                  <td>Jenis Kelamin</td>
                  <td><div align="center"><strong>:</strong></div></td>
                  <td><label><?php echo $siswa_jk;?></label></td>
			    </tr>
                <tr>
                  <td height="21">&nbsp;</td>
                  <td>Tempat Lahir</td>
                  <td><div align="center"><strong>:</strong></div></td>
                  <td><label><?php echo $siswa_tempat_lahir;?></label></td>
			    </tr>
                <tr>
                  <td>&nbsp;</td>
                  <td>Tanggal Lahir</td>
                  <td><div align="center"><strong>:</strong></div></td>
                  <td><label><span class="style8"><?php echo $siswa_tgl_lahir;?> <?php echo $bulan_lahir;?> <?php echo $tahun_lahir;?> </span></label></td>
			    </tr>
                
                
                
                <tr>
                  <td>&nbsp;</td>
                  <td>Alamat Lengkap</td>
                  <td><div align="center"><strong>:</strong></div></td>
                  <td><label></label>
                      <label for="textarea"></label>
                      <label for="textfield"></label>
                      <?php echo $siswa_alamat;?></td>
                  <td>&nbsp;</td>
                </tr>
                
                <tr>
                  <td>&nbsp;</td>
                  <td colspan="4" bgcolor="#CCCCCC">B. IDENTITAS ORANG TUA/WALI </td>
                </tr>
                <tr>
                  <td>&nbsp;</td>
                  <td>Nama Ayah </td>
                  <td><div align="center"><strong>:</strong></div></td>
                  <td><?php echo $siswa_ayah;?></td>
                </tr>

                <tr>
                  <td>&nbsp;</td>
                  <td>Nama Ibu </td>
                  <td><div align="center"><strong>:</strong></div></td>
                  <td><?php echo $siswa_ibu;?></td>
                </tr>
                
                
                <tr>
                  <td>&nbsp;</td>
                  <td>Pekerjaan</td>
                  <td><div align="center"><strong>:</strong></div></td>
                  <td><?php echo $hpeker_w['pekerjaan_nama'];?></td>
                </tr>
                <tr>
                  <td>&nbsp;</td>
                  <td>Alamat</td>
                  <td><div align="center"><strong>:</strong></div></td>
                  <td><?php echo $siswa_alamat;?></td>
                </tr>                
                <tr>
                  <td>&nbsp;</td>
                  <td>&nbsp;</td>
                  <td>&nbsp;</td>
                  <td>&nbsp;</td>
                </tr>
                <tr>
                  <td>&nbsp;</td>
                  <td>&nbsp;</td>
                  <td>&nbsp;</td>
                  <td></td>
                </tr>
                <tr>
                  <td>&nbsp;</td>
                  <td>&nbsp;</td>
                  <td>&nbsp;</td>
                  <td colspan="2"><div align="right">
                    <table width="220" border="0">
                      <tr>
                        <td>Yogyakarta, </td>
                      </tr>
                    </table>
                    </div></td>
                </tr>
                <tr>
                  <td>&nbsp;</td>
                  <td>&nbsp;</td>
                  <td>&nbsp;</td>
                  <td>&nbsp;</td>
                  <td>&nbsp;</td>
                </tr>
                <tr>
                  <td>&nbsp;</td>
                  <td>&nbsp;</td>
                  <td>&nbsp;</td>
                  <td>&nbsp;</td>
                  <td>&nbsp;</td>
                </tr>
                <tr>
                  <td>&nbsp;</td>
                  <td>&nbsp;</td>
                  <td>&nbsp;</td>
                  <td>&nbsp;</td>
                  <td>&nbsp;</td>
                </tr>
                <tr>
                  <td>&nbsp;</td>
                  <td>&nbsp;</td>
                  <td>&nbsp;</td>
                  <td colspan="2"><table width="200" border="0" align="right">
                    <tr>
                      <td><div align="left">(..........................................)</div></td>
                    </tr>
                  </table></td>
                </tr>
                <tr>
                  <td>&nbsp;</td>
                  <td>&nbsp;</td>
                  <td>&nbsp;</td>
                  <td colspan="2"><table width="220" border="0" align="right">
                    <tr>
                      <td><div align="left">NIP :........................................</div></td>
                    </tr>
                  </table></td>
                </tr>
                <tr>
                  <td>&nbsp;</td>
                  <td>&nbsp;</td>
                  <td>&nbsp;</td>
                  <td>&nbsp;</td>
                  <td>&nbsp;</td>
                </tr>
              </table>
              </form>
          </td>
          </tr>
</table>
        </form>    </td>
  </div>
		<script language="javascript">
window.print();
</script>
</body>
</html>