<?php 
error_reporting(E_ALL && E_DEPRECATED ^ E_NOTICE);
	include "../include/koneksi.php";
	session_start();
	
	$id_user = $_SESSION['user_name'];
	//cek level user
	if($_SESSION['level']!="admin"){header("Location:../include/previleges.php");}
?>

<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>


		<!--- box border -->
		<div id="lb">
		<div id="rb">
		<div id="bb"><div id="blc"><div id="brc">
		<div id="tb"><div id="tlc"><div id="trc">
		<!--  -->
				
		<div id="content" style="margin-left:-20px;">
    	<td colspan="2" bgcolor="#EEEEEE"><div align="center"></div></td>
  </tr>
  <?php include "atasprint.php";?>
  <tr>
  <td width="265"><div align="right"></div></td>
    <td width="169" bgcolor="#FFFFFF">
      <label></label></td>
    <td width="325">&nbsp;</td>
  </tr>
  <tr>
    <td colspan="3">&nbsp;</td>
  </tr>
  <tr>
    <td>&nbsp;</td>
    <td bgcolor="#FFFFFF">
      <label></label>        </td>
    <td>&nbsp;</td>
    <td colspan="2">&nbsp;</td>
  </tr>
  <tr>
    <td colspan="2">&nbsp;</td>
  </tr>
  
  
  <tr>
    <td colspan="2"><div align="center"><table width="1293" border="0">
  <tr>
    <td width="1307"><div align="left">
        <table width="200" border="0">
          <tr>
            <td>&nbsp;</td>
          </tr>
        </table>
        <table width="1271" border="1" align="center" cellpadding="0" cellspacing="0" bordercolor="#666666">
          <tr>
            <td width="20" rowspan="2" bgcolor="#CCCCCC"><div align="center">No</div></td>
            <td width="58" rowspan="2" bgcolor="#CCCCCC"><div align="center">NISN</div></td>
            <td width="58" rowspan="2" bgcolor="#CCCCCC"><div align="center">NIS</div></td>
            <td width="58" rowspan="2" bgcolor="#CCCCCC"><div align="center">NIK</div></td>
            <td width="84" rowspan="2" bgcolor="#CCCCCC"><div align="center">Nama Siswa</div></td>
            <td width="80" rowspan="2" bgcolor="#CCCCCC"><div align="center">Tempat Lahir </div></td>
            <td width="125" rowspan="2" bgcolor="#CCCCCC"><div align="center">Tanggal Lahir </div></td> 
            <td width="28" rowspan="2" bgcolor="#CCCCCC"><div align="center">L/P</div></td>                        
            <td width="75" rowspan="2" bgcolor="#CCCCCC"><div align="center">Alamat</div></td>
          	<td width="87" rowspan="2" bgcolor="#CCCCCC"><div align="center">Nama Ayah </div></td>
            <td width="87" rowspan="2" bgcolor="#CCCCCC"><div align="center">Nama Ibu </div></td>
            <td width="87" rowspan="2" bgcolor="#CCCCCC"><div align="center">Pekerjaan Wali </div></td>            
            <td width="80" rowspan="2" bgcolor="#CCCCCC"><div align="center">Kelas</div></td>
          </tr>
          <tr>
            
          </tr>
          <tr>
            <?php
  $sql ="select * from tbl_siswa"; 
  
  $qry= mysql_query($sql,$koneksi) or die ("Query Gagal ".mysql_error());
  $no=1;
  while($x=mysql_fetch_array($qry))
  {
    $siswa_nisn=$x[0];
    $siswa_nis=$x[1];
    $siswa_nik=$x[2];
    $siswa_nama=$x[3];
    $siswa_tempat_lahir=$x[4];
    $siswa_tgl_lahir=$x[5];
    $siswa_jk=$x[6];
    $siswa_alamat=$x[7];
    $siswa_ayah=$x[8];
    $siswa_ibu=$x[9];
    $siswa_pekerjaan_ortu=$x[10];
    $siswa_kelas=$x[11];

?>
            
            <td><div align="center"> <?php echo $siswa_nisn;?> </div></td>
            <td><div align="center"><?php echo $siswa_nis;?></div></td>
            <td><div align="left"><?php echo $siswa_nik;?></div></td>
            <td><div align="center"><?php echo $siswa_nama;?></div></td>
            <td><div align="left"><?php echo $siswa_tempat_lahir;?></div></td>
            <td><div align="left"><?php echo $siswa_tgl_lahir;?></div></td>
            <td><div align="left"><?php echo $siswa_jk;?></div></td>
            <td><div align="center"><?php echo $siswa_alamat;?></div></td>
            <td><div align="left"><?php echo $siswa_ayah;?></div></td>
            <td><div align="left"><?php echo $siswa_ibu;?></div></td>
            <td><div align="left"><?php echo $siswa_pekerjaan_ortu;?></div></td>
            <td><div align="left"><?php echo $siswa_kelas;?></div></td>            
          </tr>
          <?php $no++; } ?>
        </table>
    </div></td>
  </tr>
</table>
</div></td>
  </tr>
  <tr>
    <td colspan="2">&nbsp;</td>
  </div></div></div>
		</div></div></div></div>
		<!-- -->
		
</div></form>
<script language="javascript">
window.print();
</script>
</body>
</html><!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">

