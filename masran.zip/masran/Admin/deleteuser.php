<?php
error_reporting(E_ALL && E_DEPRECATED ^ E_NOTICE);
	include "../include/koneksi.php";

$koneksi=mysql_connect($host,$user,$pass) or die ("Gagal koneksi ke server".mysql_error());

if ($koneksi) {

mysql_select_db($db,$koneksi) or die ("Database Gagal Dibuka".mysql_error());

$admin_id = $_GET['admin_id'];

$sql = "delete from tbl_admin where admin_id='$admin_id'";

mysql_query($sql, $koneksi) or die ("Gagal Query Simpan" .mysql_error());
echo "<script type='text/javascript'>alert('Data User Berhasil Dihapus'), window.location = 'user.php'</script>";
	}
//include_once "user.php";
?>