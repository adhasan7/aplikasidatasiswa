<?php
error_reporting(E_ALL && E_DEPRECATED ^ E_NOTICE);

include "../include/koneksi.php";

$koneksi=mysql_connect($host,$user,$pass) or die ("Gagal koneksi ke server".mysql_error());

if ($koneksi) {

mysql_select_db($db,$koneksi) or die ("Database Gagal Dibuka".mysql_error());

$admin_nama=$_POST["admin_nama"];
$user_name = $_POST['user_name'];
$pass = md5($_POST['pass']);
$level='admin';
$SQL = "insert into tbl_admin (admin_nama,admin_username,admin_password,admin_level) VALUES('$admin_nama','$user_name','$pass','$level')";


mysql_query($SQL, $koneksi) or die ("Gagal Query Simpan data user" .mysql_error());
echo "<script type='text/javascript'>alert('Data User Berhasil Disimpan'), window.location = 'user.php'</script>";
}
?>