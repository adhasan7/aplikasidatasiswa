<?php 
error_reporting(E_ALL && E_DEPRECATED ^ E_NOTICE);
include "../include/koneksi.php";
session_start();

$id_user = $_SESSION['user_name'];
	//cek level user
	if($_SESSION['level']!="admin"){header("Location:../include/previleges.php");}

$NIS = $_GET['NIS'];
$kelas="0";
$pekerjaan="not available";
$qry=mysql_query("select * from tbl_siswa where siswa_nis='$NIS'");

$siswa_nisn="not available";
$siswa_nis="not available";
$siswa_nik="not available";
$siswa_nama="not available";
$siswa_tempat_lahir="not available";
$siswa_tgl_lahir="not available";
$siswa_jk="not available";
$siswa_alamat="not available";
$siswa_ayah="not available";
$siswa_ibu="not available";
$siswa_pekerjaan_ortu="not available";
$siswa_kelas="not available";

while($x=mysql_fetch_array($qry)){
  $siswa_nisn=$x[0];
  $siswa_nis=$x[1];
  $siswa_nik=$x[2];
  $siswa_nama=$x[3];
  $siswa_tempat_lahir=$x[4];
  $siswa_tgl_lahir=$x[5];
  $siswa_jk=$x[6];
  $siswa_alamat=$x[7];
  $siswa_ayah=$x[8];
  $siswa_ibu=$x[9];
  $siswa_pekerjaan_ortu=$x[10];
  $siswa_kelas=$x[11]; 
}

$kls_s=mysql_query("select * from `tbl_kelas` where `kelas_id`='$siswa_kelas'");
$res=mysql_fetch_array($kls_s);
if($res){
  while($x=mysql_fetch_array($res)){
    $siswa_kelas=$x[1];
  }
}

$pek_s=mysql_query("select * from `tbl_pekerjaan` where `pekerjaan_id`='$siswa_pekerjaan_ortu'");
$res=mysql_fetch_array($pek_s);
if($res){
  while($x=mysql_fetch_array($res)){
    $siswa_pekerjaan_ortu=$x[1];
  }
}
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
  <?php include "atas.php";?>

    
		<!--- box border -->
		<div id="lb">
		<div id="rb">
		<div id="bb"><div id="blc"><div id="brc">
		<div id="tb"><div id="tlc"><div id="trc">
		<!--  -->
				
		<div id="content">
    
  
    <td><form id="form1" name="form1" method="post" action="updatedaftar.php">
      <table width="813" border="0">
        
        <tr>
          <td>&nbsp;</td>
          <td colspan="3"><div align="center" class="style3">Edit  Data Siswa  </div></td>
          <td>&nbsp;</td>
        </tr>
        <tr>
          <td width="77">&nbsp;</td>
          <td colspan="3" bgcolor="#CCCCCC"><strong>A.IDENTITAS SISWA </strong>
            <label></label></td>
          <td width="77">&nbsp;</td>
        </tr>
        <tr>
          <td>&nbsp;</td>
          <td width="169"> NIS</td>
          <td width="10"><div align="center"><strong>:</strong></div></td>
          <td width="458"><?php echo $NIS;?>
            <label>
            <input type="hidden" name="siswa_nis" size="size""5" value="<?php echo $NIS;?>" />
            </label>
            <label></label></td>
          <td>&nbsp;</td>
        </tr>
        </tr>
        <tr>
          <td>&nbsp;</td>
          <td>Nama</td>
          <td><div align="center"><strong>:</strong></div></td>
          <td><input type="text" name="siswa_nama" value="<?php echo $siswa_nama;?>" /></td>
          <td>&nbsp;</td>
        </tr>
        <tr>
          <td>&nbsp;</td>
          <td>Jenis Kelamin </td>
          <td><div align="center"><strong>:</strong></div></td>
          <td>
            <input name="siswa_jk" type="radio" value="L" id="radiobutton2" <?php if($siswa_jk == 'L'){echo "checked";}?> />
            L
  			<input name="siswa_jk" type="radio" value="P" id="radio" <?php if($siswa_jk == 'P'){echo "checked";}?> />
            P </td>
          <td>&nbsp;</td>
        </tr>
        <tr>
          <td>&nbsp;</td>
          <td>Tempat lahir </td>
          <td><div align="center"><strong>:</strong></div></td>
          <td><input type="text" name="siswa_tempat_lahir" value="<?php echo $siswa_tempat_lahir;?>" /></td>
          <td><label></label></td>
        </tr>
        <tr>
          <td>&nbsp;</td>
          <td>Tanggal lahir </td>
          <td><div align="center"><strong>:</strong></div></td>
          <td><input type="date" id="to" name="siswa_tgl_lahir" size="9" value="<?php echo $siswa_tgl_lahir; ?>" onClick="if(self.gfPop)gfPop.fPopCalendar(document.form1.to);return false;"/><a href="javascript:void(0)" onClick="if(self.gfPop)gfPop.fPopCalendar(document.form1.tgl_lahir);return false;" ><img name="popcal" align="center" style="border:none" src="./calender/calender.jpeg" width="34" height="29" border="0" alt=""></a> 
		   <iframe width=174 height=189 name="gToday:normal:calender/agenda.js" id="gToday:normal:calender/agenda.js" src="calender/ipopeng.htm" scrolling="no" frameborder="0" style="visibility:visible; z-index:999; position:absolute; top:-500px; left:500px;">
</iframe>
		   </td>
		  <tr>
          <td>&nbsp;</td>
          <td>Kelas</td>
          <td><div align="center"><strong>:</strong></div></td>
          <td><select name="siswa_kelas" id="id_kelas">
            <option value="0" selected="selected"> [-pilih-]</option>
            <?php
		  $sql="select * from tbl_kelas ";
		  $qry= mysql_query($sql);
		  
		  while ($data=mysql_fetch_array($qry)){
		  if ($data[kelas_id]==$siswa_kelas){
		  $cek="selected";
		  }
		  else
		  {
		  $cek="";
		  }
		  echo"<option value='$data[kelas_id]' $cek> $data[kelas_nama]</option>";
		  }
		  ?>
          </select></td>
          <td>&nbsp;</td>
        </tr>
        
		  
		  
        
       
        <tr>
          <td>&nbsp;</td>
          <td width="169">Alamat</td>
          <td><div align="center"><strong>:</strong></div></td>
                <td><textarea name="siswa_alamat"><?php echo $siswa_alamat;?></textarea></td>
                <td>&nbsp;</td>
        </tr>        

        
        <tr>
          <td>&nbsp;</td>
          <td>&nbsp;</td>
          <td>&nbsp;</td>
          <td>&nbsp;</td>
          <td>&nbsp;</td>
        </tr>
        <tr>
          <td>&nbsp;</td>
          <td>&nbsp;</td>
          <td>&nbsp;</td>
          <td>&nbsp;</td>
          <td>&nbsp;</td>
        </tr>
        <tr>
          <td>&nbsp;</td>
          <td>Nama Ayah </td>
          <td><div align="center">:</div></td>
          <td><input type="text" name="siswa_ayah" value="<?php echo $siswa_ayah;?>" /></td>
          <td>&nbsp;</td>
        </tr>
        
        
        
        <tr>
          <td>&nbsp;</td>
          <td>Pekerjaan</td>
          <td><div align="center">:</div></td>
          <td><select name="siswa_pekerjaan_ortu" id="id_pekerjaan">
            <option value="Notid_pekerjaan_w" selected="selected"> [---Pilih---]</option>
            <?php
		  $sql="select pekerjaan_id,pekerjaan_nama from tbl_pekerjaan order by pekerjaan_id";
		  $qry= mysql_query($sql);
		  
		  while ($data=mysql_fetch_array($qry)){
		  if ($data[pekerjaan_id]==$siswa_pekerjaan_ortu){
		  $cek1="selected";
		  }
		  else
		  {
		  $cek1="";
		  }
		  echo"<option value='$data[pekerjaan_id]' $cek1> $data[pekerjaan_nama]</option>";
		  }
		  ?>
          </select></td>
          <td>&nbsp;</td>
        </tr>
        <tr>
          <td>&nbsp;</td>
          <td>Alamat</td>
          <td><div align="center">:</div></td>
          <td><textarea name="siswa_alamat"><?php echo $siswa_alamat;?></textarea></td>
          <td>&nbsp;</td>
        </tr>
        
        <tr>
          <td>&nbsp;</td>
          <td>&nbsp;</td>
          <td>&nbsp;</td>
          <td>&nbsp;</td>
          <td>&nbsp;</td>
        </tr>
        
        <tr>
          <td>&nbsp;</td>
          <td>&nbsp;</td>
          <td>&nbsp;</td>
          <td><input type="submit" name="Submit" value="Update" /></td>
          <td>&nbsp;</td>
        </tr>
      </table>
        </form>    </td>
  </tr>
        </form>    </td>
  </tr>

  <input type="hidden" name="siswa_nis" value="$NIS">
    </form>
    </div>
		
		<!--- end of box border -->
		</div></div></div></div>
		</div></div></div></div>
		<!-- -->
	<?php include "../css/footer.php"; ?>		
</div>
</body>
</html>