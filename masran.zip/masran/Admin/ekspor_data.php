<?php 
error_reporting(E_ALL && E_DEPRECATED ^ E_NOTICE);
	include "../include/koneksi.php";
	session_start();
	
	$id_user = $_SESSION['user_name'];
	//cek level user
	if($_SESSION['level']!="admin"){header("Location:../include/previleges.php");}
?>
<?php 
include "excel.php";
//query database untuk menampilkan data siswa

  $sql ="select * from tbl_siswa"; 
  
  $qry= mysql_query($sql,$koneksi) or die ("Query Gagal ".mysql_error());
  $no=1;
  $pekerjaan=array();	
  while($res=mysql_fetch_array($qry))
  {
  
  
//mengambil data siswa dari database dimasukan ke array
$data['siswa_nis'][] = $res['siswa_nis'];
$data['siswa_nama'][] = $res['siswa_nama'];
$data['siswa_jk'][] = $res['siswa_jk'];
$data['siswa_tempat_lahir'][] = $res['siswa_tempat_lahir'];
$data['siswa_tgl_lahir'][]= $res['siswa_tgl_lahir'];
$data['siswa_kelas'][] = $res['siswa_kelas'];
$data['siswa_ayah'][] = $res['siswa_ayah'];
$data['siswa_ibu'][] = $res['siswa_ibu'];

	
	$query_pekerjaan="SELECT * FROM tbl_pekerjaan WHERE pekerjaan_id=$res[10]";
	$hasil=mysql_query($query_pekerjaan)  or die(mysql_error());
	if($hasil){
		while($row=mysql_fetch_array($hasil)){			
			//$pekerjaan[$no]=$row[1]);						
			array_push($pekerjaan, $row[1]);
		}
	}
	$data['siswa_alamat'][] = $res['siswa_alamat'];
	$no++;
}
//untuk primary key table data_siswa yaitu id_siswa
$jm = sizeof($data['siswa_nis']);
header("Pragma: public");
header("Expires: 0");
header("Cache-Control: must-revalidate, post-check=0, pre-check=0");
header("Content-Type: application/force-download");
header("Content-Type: application/octet-stream");
header("Content-Type: application/download");
header("Content-Disposition: attachment;filename=data_siswa.xls");
header("Content-Transfer-Encoding: binary");
xlsBOF();
/*
posisi excel berdasarkan baris dan kolom
diaplikasi posisinya berdasarkan nomor array dimulai dari 0
sedangkan di excel dimulai dari 1
ini untuk judul di excel. posisinya di baris array 0, kolom array 3
berarti posisi di excel 0 berarti baris 1, dan 3 berarti kolom 4
*/
xlsWriteLabel(0,7,"DATA SISWA");
/*
untuk nama2 field dimulai dari baris array 2(baris 3 di excel)
untuk kolomnya dimulai dari array 0(baris 1 di excel)
*/
xlsWriteLabel(2,0,"No");
xlsWriteLabel(2,1,"NIS" );
xlsWriteLabel(2,2,"Nama Siswa" );
xlsWriteLabel(2,3,"Tempat Lahir" );
xlsWriteLabel(2,4,"Tanggal Lahir" );
xlsWriteLabel(2,5,"L/P" );
xlsWriteLabel(2,6,"Kelas" );
xlsWriteLabel(2,7,"Nama Ayah" );
xlsWriteLabel(2,8,"Nama Ibu" );
xlsWriteLabel(2,9,"Pekerjaan Ortu" );
xlsWriteLabel(2,10,"Alamat Wali" );


/*
untuk mulai baris data (row) dimulai pada array 3(baris 4 di excel)
*/
$xlsRow = 3;
//untuk menampilkan data dari database di file excel
for ($y=0; $y<$jm; $y++) {
++$i;
xlsWriteNumber($xlsRow,0,"$i");
xlsWriteLabel($xlsRow,1,$data['siswa_nis'][$y]);
xlsWriteLabel($xlsRow,2,$data['siswa_nama'][$y]);
xlsWriteLabel($xlsRow,3,$data['siswa_tempat_lahir'][$y]);
xlsWriteLabel($xlsRow,4,$data['siswa_tgl_lahir'][$y]);
xlsWriteLabel($xlsRow,5,$data['siswa_jk'][$y]);
xlsWriteLabel($xlsRow,6,$data['siswa_kelas'][$y]);
xlsWriteLabel($xlsRow,7,$data['siswa_ayah'][$y]);
xlsWriteLabel($xlsRow,8,$data['siswa_ibu'][$y]);
xlsWriteLabel($xlsRow,9,$pekerjaan[$y]);		
xlsWriteLabel($xlsRow,10,$data['siswa_alamat'][$y]);

$xlsRow++;
}
xlsEOF();
exit();
?>