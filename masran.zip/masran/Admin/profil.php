<?php 
error_reporting(E_ALL && E_DEPRECATED ^ E_NOTICE);
	include "../include/koneksi.php";
	session_start();
	
	$id_user = $_SESSION['user_name'];
	//cek level user
	if($_SESSION['level']!="admin"){header("Location:../include/previleges.php");}

	$admin_username=$_SESSION["admin_username"];
  	if(empty($admin_username)){
    	header("location:../index.php");
    	exit();
  	}
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>

<?php


			include "atas.php";
			
 ?>      
		<!--- box border -->
		<div id="lb">
		<div id="rb">
		<div id="bb"><div id="blc"><div id="brc">
		<div id="tb"><div id="tlc"><div id="trc">
		<!--  -->
        
 		<div id="content">
		<p h2 align="left"><strong><span class="">Selamat Datang di Sistem Idnformasim Data Siswa
		</span></strong><?php include "../css/utama.php"; ?>
		</span></strong>
 		</div>

    </div>

        <br>
        <br>
        <br>
        
        
		<!--- end of box border -->
		</div></div></div></div>
		</div></div></div></div>
		<!-- -->
		<?php include "../css/footer.php"; ?>
	</div>
</body>
</html>