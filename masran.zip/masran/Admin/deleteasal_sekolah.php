<?php
error_reporting(E_ALL && E_DEPRECATED ^ E_NOTICE);
error_reporting(E_ALL && E_DEPRECATED ^ E_NOTICE);

include "../include/koneksi.php";

$koneksi = mysql_connect($host,$user,$pass) or die (mysql_error());
if ($koneksi) {
mysql_select_db($db,$koneksi) or die (mysql_error());
}
$id_sekolah= $_GET['id_sekolah'];

$sql="delete from tbl_asal_sekolah where asek_id='$id_sekolah'";
	
mysql_query($sql,$koneksi) or die ("Gagal Menghapus data Sekolah" .mysql_error());

include_once "asal_sekolah.php";

?>
