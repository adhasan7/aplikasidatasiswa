<?php
error_reporting(E_ALL && E_DEPRECATED ^ E_NOTICE);
include "../include/koneksi.php";	


$koneksi = mysql_connect($host,$user,$pass) or die (mysql_error());
if ($koneksi) {
	mysql_select_db($db,$koneksi) or die (mysql_error());

$id_user = $_POST['admin_id'];
$user_name = $_POST['admin_username'];
$pass = md5($_POST['admin_password']);
$level = $_POST['admin_level'];

$sql = "update tbl_admin SET admin_username='$user_name',admin_password='$pass',admin_level='$level' where admin_id='$id_user'";

mysql_query($sql,$koneksi) or die ("Gagal Query Update" .mysql_error());
 include_once "user.php";
}
?>
 
