<?php
error_reporting(E_ALL && E_DEPRECATED ^ E_NOTICE);

include "../include/koneksi.php";

$koneksi = mysql_connect($host,$user,$pass) or die (mysql_error());


function spasi($s)
{
	$spasi=str_replace(" ","_", $s);
	return($spasi);
}

$siswa_nisn=$_POST["siswa_nisn"];
$siswa_nis=$_POST["siswa_nis"];
$siswa_nik=$_POST["siswa_nik"];
$siswa_nama=$_POST["siswa_nama"];
$siswa_tempat_lahir=$_POST["siswa_tempat_lahir"];
$siswa_tgl_lahir=$_POST["siswa_tgl_lahir"];
$siswa_jk=$_POST["siswa_jk"];
$siswa_alamat=$_POST["siswa_alamat"];
$siswa_ayah=$_POST["siswa_ayah"];
$siswa_ibu=$_POST["siswa_ibu"];
$siswa_pekerjaan_ortu=$_POST["siswa_pekerjaan_ortu"];
$siswa_kelas=$_POST["siswa_kelas"];

echo $siswa_nisn."<br />";
echo $siswa_nis."<br />";
echo $siswa_nik."<br />";
echo $siswa_nama."<br />";
echo $siswa_tempat_lahir."<br />";
echo $siswa_tgl_lahir."<br />";
echo $siswa_jk."<br />";
echo $siswa_alamat."<br />";
echo $siswa_ayah."<br />";
echo $siswa_ibu."<br />";
echo $siswa_pekerjaan_ortu."<br />";
echo $siswa_kelas."<br />";


$path='../foto_siswa/';
$filename=spasi($_FILES['gambar']['name']);
move_uploaded_file($_FILES['gambar']['tmp_name'], $path.$filename);

if(!$_POST['siswa_nis'] | !$_POST['siswa_nama'] )
{
	header("location:form_input_data.php?kosong=1");
}
else
{

	$siswa="INSERT INTO tbl_siswa (siswa_nisn
	,siswa_nis
	,siswa_nik
	,siswa_nama
	,siswa_tempat_lahir
	,siswa_tgl_lahir
	,siswa_jk
	,siswa_alamat
	,siswa_ayah
	,siswa_ibu
	,siswa_pekerjaan_ortu,siswa_kelas)

	VALUES ('$siswa_nisn','$siswa_nis','$siswa_nik','$siswa_nama','$siswa_tempat_lahir','$siswa_tgl_lahir','$siswa_jk','$siswa_alamat','$siswa_ayah','$siswa_ibu','$siswa_pekerjaan_ortu','$siswa_kelas')";
		
	mysql_query($siswa,$koneksi) or die ("Gagal Query simpan Data Siswa" .mysql_error());

	echo("<META HTTP-EQUIV=Refresh CONTENT=\"0.1;URL=http://localhost/datasiswa/Admin/view_siswa.php?NIS=$siswa_nis\">");
}
?>