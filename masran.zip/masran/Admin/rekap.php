<?php 
error_reporting(E_ALL && E_DEPRECATED ^ E_NOTICE);
	include "../include/koneksi.php";
	session_start();
	
	$id_user = $_SESSION['user_name'];
	//cek level user
	if($_SESSION['level']!="admin"){header("Location:../include/previleges.php");}

?>

<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<body>    


		<!--- box border -->
		<div id="lb">
		<div id="rb">
		<div id="bb"><div id="blc"><div id="brc">
		<div id="tb"><div id="tlc"><div id="trc">
		<!--  -->
				
		<div id="content" style="margin-left:-20px;">
    	<td colspan="2" bgcolor="#EEEEEE"><div align="center"></div></td>
  </tr>
  <?php include "atasprint.php";?>
  <tr>
  <td width="265"><div align="right"></div></td>
    <td width="169" bgcolor="#FFFFFF">
      <label></label></td>
    <td width="325">&nbsp;</td>
  </tr>
  <tr>
    <td colspan="3">&nbsp;</td>
  </tr>
  <tr>
    <td>&nbsp;</td>
    <td bgcolor="#FFFFFF">
      <label></label>        </td>
    <td>&nbsp;</td>
    <td colspan="2">&nbsp;</td>
  </tr>
  <tr>
    <td colspan="2">&nbsp;</td>
  </tr>
  
  
  <tr>
    <td colspan="2"><div align="center"><table width="1298" border="0">
  <tr>
    <td width="1298"><div align="left">
        <table width="200" border="0">
          <tr>
            <td>&nbsp;</td>
            <td>&nbsp;</td>
            <td><a href="index.php">kembali</a></td>
            <td><a href="rekap2.php" target="_blank" "javascript:window.print()">Print</a></td>
            <td><a href="ekspor_data.php">Excel</a></td>
          </tr>
        </table>
        <table width="1271" border="1" align="center" cellpadding="0" cellspacing="0" bordercolor="#666666">
          <tr>
            <td width="20" rowspan="2" bgcolor="#CCCCCC"><div align="center">No</div></td>
            <td width="58" rowspan="2" bgcolor="#CCCCCC"><div align="center">NIS</div></td>
            <td width="84" rowspan="2" bgcolor="#CCCCCC"><div align="center">Nama Siswa</div></td>
            <td width="28" rowspan="2" bgcolor="#CCCCCC"><div align="center">L/P</div></td>
            <td width="80" rowspan="2" bgcolor="#CCCCCC"><div align="center">Kelas</div></td>
            <td width="80" rowspan="2" bgcolor="#CCCCCC"><div align="center">Tempat Lahir </div></td>
            <td width="125" rowspan="2" bgcolor="#CCCCCC"><div align="center">Tanggal Lahir </div></td>            
            <td width="87" rowspan="2" bgcolor="#CCCCCC"><div align="center">Nama Wali </div></td>
            <td width="87" rowspan="2" bgcolor="#CCCCCC"><div align="center">Pekerjaan Wali </div></td>
            <td width="157" rowspan="2" bgcolor="#CCCCCC"><div align="center">Alamat Wali </div></td>
          </tr>
          <tr>
            
          </tr>
          <tr>

            <?php
$qry=mysql_query("select * from tbl_siswa");

$siswa_nisn="not available";
$siswa_nis="not available";
$siswa_nik="not available";
$siswa_nama="not available";
$siswa_tempat_lahir="not available";
$siswa_tgl_lahir="not available";
$siswa_jk="not available";
$siswa_alamat="not available";
$siswa_ayah="not available";
$siswa_ibu="not available";
$siswa_pekerjaan_ortu="not available";
$siswa_kelas="not available";

while($x=mysql_fetch_array($qry)){
  $siswa_nisn=$x[0];
  $siswa_nis=$x[1];
  $siswa_nik=$x[2];
  $siswa_nama=$x[3];
  $siswa_tempat_lahir=$x[4];
  $siswa_tgl_lahir=$x[5];
  $siswa_jk=$x[6];
  $siswa_alamat=$x[7];
  $siswa_ayah=$x[8];
  $siswa_ibu=$x[9];
  $siswa_pekerjaan_ortu=$x[10];
  $siswa_kelas=$x[11]; 
}

echo $siswa_nisn."<br/>";
echo $siswa_nis."<br/>";
echo $siswa_nik."<br/>";
echo $siswa_nama."<br/>";
echo $siswa_tempat_lahir."<br/>";
echo $siswa_tgl_lahir."<br/>";
echo $siswa_jk."<br/>";
echo $siswa_alamat."<br/>";
echo $siswa_ayah."<br/>";
echo $siswa_ibu."<br/>";
echo $siswa_pekerjaan_ortu."<br/>";
echo $siswa_kelas."<br/>";
exit();

$kls_s=mysql_query("select * from `tbl_kelas` where `kelas_id`='$siswa_kelas'");
$res=mysql_fetch_array($kls_s);
if($res){
  while($x=mysql_fetch_array($res)){
    $siswa_kelas=$x[1];
  }
}

$pek_s=mysql_query("select * from `tbl_pekerjaan` where `pekerjaan_id`='$siswa_pekerjaan_ortu'");
$res=mysql_fetch_array($pek_s);
if($res){
  while($x=mysql_fetch_array($res)){
    $siswa_pekerjaan_ortu=$x[1];
  }
}

?>
            <td><div align="center"> <?php echo $no;?> </div></td>
            <td><div align="center"><?php echo $siswa_nis;?></div></td>
            <td><div align="left"><?php echo $siswa_nama;?></div></td>
            <td><div align="center"><?php echo $siswa_jk;?></div></td>
            <td><div align="left"><?php echo $siswa_kelas;?></div></td>
            <td><div align="left"><?php echo $siswa_tempat_lahir;?></div></td>
            <td><div align="left"><?php echo $siswa_tgl_lahir;?></div></td>            
            <td><div align="left"><?php echo $siswa_ayah;?></div></td>
            <td><div align="left"><?php echo $siswa_pekerjaan_ortu;?></div></td>
            <td><div align="left"><?php echo $siswa_alamat;?></div></td>
          </tr>
          <php $no++; } ?>
        </table>
    </div></td>
  </tr>
</table>
</div></td>
  </tr>
  <tr>
    <td colspan="2">&nbsp;</td>
  </div></div></div>
		</div></div></div></div>
		<!-- -->
		
</div></form>
</body>
</html>